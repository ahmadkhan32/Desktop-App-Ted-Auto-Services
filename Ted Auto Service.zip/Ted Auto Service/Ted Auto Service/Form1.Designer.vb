﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TedAutoServiceLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TotalTxtBox = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DisCheckBox = New System.Windows.Forms.CheckBox()
        Me.CarShowLabel = New System.Windows.Forms.Label()
        Me.CustomerShowLabel = New System.Windows.Forms.Label()
        Me.CarRegTxtBox = New System.Windows.Forms.TextBox()
        Me.customerTxtBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.WheelAlignmentRadioButton = New System.Windows.Forms.RadioButton()
        Me.WheelBalanceRadioButton = New System.Windows.Forms.RadioButton()
        Me.TransmissionRadioButton = New System.Windows.Forms.RadioButton()
        Me.TuneupRadioButton = New System.Windows.Forms.RadioButton()
        Me.ServiceRadioButton = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SubmitButton = New System.Windows.Forms.Button()
        Me.SummaryButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.SkyBlue
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(794, 33)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(54, 29)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ClearToolStripMenuItem1
        '
        Me.ClearToolStripMenuItem1.Name = "ClearToolStripMenuItem1"
        Me.ClearToolStripMenuItem1.Size = New System.Drawing.Size(153, 34)
        Me.ClearToolStripMenuItem1.Text = "Clear"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(153, 34)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(65, 29)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(164, 34)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'TedAutoServiceLabel
        '
        Me.TedAutoServiceLabel.AutoSize = True
        Me.TedAutoServiceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TedAutoServiceLabel.ForeColor = System.Drawing.Color.Firebrick
        Me.TedAutoServiceLabel.Location = New System.Drawing.Point(281, 63)
        Me.TedAutoServiceLabel.Name = "TedAutoServiceLabel"
        Me.TedAutoServiceLabel.Size = New System.Drawing.Size(355, 46)
        Me.TedAutoServiceLabel.TabIndex = 1
        Me.TedAutoServiceLabel.Text = "Ted's Auto Service"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ScrollBar
        Me.Label1.Location = New System.Drawing.Point(24, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 46)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "T"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label2.Location = New System.Drawing.Point(55, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 55)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "A"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkOrange
        Me.Label3.Location = New System.Drawing.Point(104, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 46)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "S"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TotalTxtBox)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.DisCheckBox)
        Me.Panel1.Controls.Add(Me.CarShowLabel)
        Me.Panel1.Controls.Add(Me.CustomerShowLabel)
        Me.Panel1.Controls.Add(Me.CarRegTxtBox)
        Me.Panel1.Controls.Add(Me.customerTxtBox)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Location = New System.Drawing.Point(26, 133)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(698, 269)
        Me.Panel1.TabIndex = 5
        '
        'TotalTxtBox
        '
        Me.TotalTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalTxtBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.TotalTxtBox.ForeColor = System.Drawing.SystemColors.ScrollBar
        Me.TotalTxtBox.Location = New System.Drawing.Point(173, 206)
        Me.TotalTxtBox.Name = "TotalTxtBox"
        Me.TotalTxtBox.Size = New System.Drawing.Size(139, 20)
        Me.TotalTxtBox.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(75, 206)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 20)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Total:"
        '
        'DisCheckBox
        '
        Me.DisCheckBox.AutoSize = True
        Me.DisCheckBox.Location = New System.Drawing.Point(173, 143)
        Me.DisCheckBox.Name = "DisCheckBox"
        Me.DisCheckBox.Size = New System.Drawing.Size(176, 24)
        Me.DisCheckBox.TabIndex = 4
        Me.DisCheckBox.Text = "Pay on day discount"
        Me.DisCheckBox.UseVisualStyleBackColor = True
        '
        'CarShowLabel
        '
        Me.CarShowLabel.AutoSize = True
        Me.CarShowLabel.Location = New System.Drawing.Point(7, 97)
        Me.CarShowLabel.Name = "CarShowLabel"
        Me.CarShowLabel.Size = New System.Drawing.Size(134, 20)
        Me.CarShowLabel.TabIndex = 3
        Me.CarShowLabel.Text = "Car Regestration:"
        '
        'CustomerShowLabel
        '
        Me.CustomerShowLabel.AutoSize = True
        Me.CustomerShowLabel.Location = New System.Drawing.Point(7, 51)
        Me.CustomerShowLabel.Name = "CustomerShowLabel"
        Me.CustomerShowLabel.Size = New System.Drawing.Size(126, 20)
        Me.CustomerShowLabel.TabIndex = 2
        Me.CustomerShowLabel.Text = "Customer name:"
        '
        'CarRegTxtBox
        '
        Me.CarRegTxtBox.Location = New System.Drawing.Point(173, 91)
        Me.CarRegTxtBox.Name = "CarRegTxtBox"
        Me.CarRegTxtBox.Size = New System.Drawing.Size(139, 26)
        Me.CarRegTxtBox.TabIndex = 1
        '
        'customerTxtBox
        '
        Me.customerTxtBox.Location = New System.Drawing.Point(173, 48)
        Me.customerTxtBox.Name = "customerTxtBox"
        Me.customerTxtBox.Size = New System.Drawing.Size(192, 26)
        Me.customerTxtBox.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.WheelAlignmentRadioButton)
        Me.GroupBox1.Controls.Add(Me.WheelBalanceRadioButton)
        Me.GroupBox1.Controls.Add(Me.TransmissionRadioButton)
        Me.GroupBox1.Controls.Add(Me.TuneupRadioButton)
        Me.GroupBox1.Controls.Add(Me.ServiceRadioButton)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.Highlight
        Me.GroupBox1.Location = New System.Drawing.Point(404, 33)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(231, 211)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Service Performed"
        '
        'WheelAlignmentRadioButton
        '
        Me.WheelAlignmentRadioButton.AutoSize = True
        Me.WheelAlignmentRadioButton.Location = New System.Drawing.Point(34, 170)
        Me.WheelAlignmentRadioButton.Name = "WheelAlignmentRadioButton"
        Me.WheelAlignmentRadioButton.Size = New System.Drawing.Size(154, 24)
        Me.WheelAlignmentRadioButton.TabIndex = 0
        Me.WheelAlignmentRadioButton.TabStop = True
        Me.WheelAlignmentRadioButton.Text = "Wheel Alignment"
        Me.WheelAlignmentRadioButton.UseVisualStyleBackColor = True
        '
        'WheelBalanceRadioButton
        '
        Me.WheelBalanceRadioButton.AutoSize = True
        Me.WheelBalanceRadioButton.Location = New System.Drawing.Point(34, 130)
        Me.WheelBalanceRadioButton.Name = "WheelBalanceRadioButton"
        Me.WheelBalanceRadioButton.Size = New System.Drawing.Size(139, 24)
        Me.WheelBalanceRadioButton.TabIndex = 0
        Me.WheelBalanceRadioButton.TabStop = True
        Me.WheelBalanceRadioButton.Text = "Wheel balance"
        Me.WheelBalanceRadioButton.UseVisualStyleBackColor = True
        '
        'TransmissionRadioButton
        '
        Me.TransmissionRadioButton.AutoSize = True
        Me.TransmissionRadioButton.Location = New System.Drawing.Point(34, 100)
        Me.TransmissionRadioButton.Name = "TransmissionRadioButton"
        Me.TransmissionRadioButton.Size = New System.Drawing.Size(183, 24)
        Me.TransmissionRadioButton.TabIndex = 0
        Me.TransmissionRadioButton.TabStop = True
        Me.TransmissionRadioButton.Text = "Transmission Service"
        Me.TransmissionRadioButton.UseVisualStyleBackColor = True
        '
        'TuneupRadioButton
        '
        Me.TuneupRadioButton.AutoSize = True
        Me.TuneupRadioButton.Location = New System.Drawing.Point(34, 70)
        Me.TuneupRadioButton.Name = "TuneupRadioButton"
        Me.TuneupRadioButton.Size = New System.Drawing.Size(92, 24)
        Me.TuneupRadioButton.TabIndex = 0
        Me.TuneupRadioButton.TabStop = True
        Me.TuneupRadioButton.Text = "Tune up"
        Me.TuneupRadioButton.UseVisualStyleBackColor = True
        '
        'ServiceRadioButton
        '
        Me.ServiceRadioButton.AutoSize = True
        Me.ServiceRadioButton.Location = New System.Drawing.Point(34, 40)
        Me.ServiceRadioButton.Name = "ServiceRadioButton"
        Me.ServiceRadioButton.Size = New System.Drawing.Size(94, 24)
        Me.ServiceRadioButton.TabIndex = 0
        Me.ServiceRadioButton.TabStop = True
        Me.ServiceRadioButton.Text = "Services"
        Me.ServiceRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox2.Location = New System.Drawing.Point(65, 487)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(659, 137)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "j"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Brown
        Me.Label4.Location = New System.Drawing.Point(71, 459)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 25)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Order Details:"
        '
        'SubmitButton
        '
        Me.SubmitButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.SubmitButton.Location = New System.Drawing.Point(304, 408)
        Me.SubmitButton.Name = "SubmitButton"
        Me.SubmitButton.Size = New System.Drawing.Size(100, 33)
        Me.SubmitButton.TabIndex = 8
        Me.SubmitButton.Text = "&Submit"
        Me.SubmitButton.UseVisualStyleBackColor = True
        '
        'SummaryButton
        '
        Me.SummaryButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.SummaryButton.Location = New System.Drawing.Point(424, 408)
        Me.SummaryButton.Name = "SummaryButton"
        Me.SummaryButton.Size = New System.Drawing.Size(100, 33)
        Me.SummaryButton.TabIndex = 8
        Me.SummaryButton.Text = "&Summary"
        Me.SummaryButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ClearButton.Location = New System.Drawing.Point(574, 408)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(100, 33)
        Me.ClearButton.TabIndex = 8
        Me.ClearButton.Text = "&Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ExitButton.Location = New System.Drawing.Point(574, 447)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(100, 33)
        Me.ExitButton.TabIndex = 8
        Me.ExitButton.Text = "&Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(794, 647)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.SummaryButton)
        Me.Controls.Add(Me.SubmitButton)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TedAutoServiceLabel)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Ted Auto Service"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TedAutoServiceLabel As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents CarShowLabel As Label
    Friend WithEvents CustomerShowLabel As Label
    Friend WithEvents CarRegTxtBox As TextBox
    Friend WithEvents customerTxtBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents WheelAlignmentRadioButton As RadioButton
    Friend WithEvents WheelBalanceRadioButton As RadioButton
    Friend WithEvents TransmissionRadioButton As RadioButton
    Friend WithEvents TuneupRadioButton As RadioButton
    Friend WithEvents ServiceRadioButton As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents SubmitButton As Button
    Friend WithEvents SummaryButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents DisCheckBox As CheckBox
    Friend WithEvents TotalTxtBox As Label
    Friend WithEvents Label7 As Label
End Class
