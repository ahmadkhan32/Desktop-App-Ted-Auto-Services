﻿Public Class Form1
    Public Const discount As Decimal = 0.9
    Public discountCount As Decimal
    Public Const service As Decimal = 125
    Public Const tuneUp As Decimal = 75
    Public Const tranService As Decimal = 80
    Public Const wheelBalance As Decimal = 40
    Public Const wheelAlighment As Decimal = 65
    Public subtotal, total, grandTotal As Decimal
    Public transactionCounter As Integer = 0
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub
    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem1.Click
        ClearButton_Click(sender, e)
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        customerTxtBox.Clear()
        customerTxtBox.Focus()
        CarRegTxtBox.Clear()
        DisCheckBox.Checked = False
        ServiceRadioButton.Checked = False
        TransmissionRadioButton.Checked = False
        TuneupRadioButton.Checked = False
        WheelAlignmentRadioButton.Checked = False
        WheelBalanceRadioButton.Checked = False
        CustomerShowLabel.Text = ""
        CarShowLabel.Text = ""
        TedAutoServiceLabel.Text = ""
        TotalTxtBox.Text.Clone()

        custTextBox.Clear()
        custTextBox.Focus()
        carregTextBox.Clear()
        discountCheckBox.Checked = False
        ServiceRadioButton.Checked = False
        TransmissionRadioButton.Checked = False
        TuneupRadioButton.Checked = False
        wheelAlignRadioButton.Checked = False
        WheelBalanceRadioButton.Checked = False
        custShowNameLabel.Text = ""
        CarShowLabel.Text = ""
        serviceShowLabel.Text = ""
        totalTextBox.Clear()

    End Sub

    Private Sub SummaryButton_Click(sender As Object, e As EventArgs) Handles SummaryButton.Click
        Dim msgstr As String
        msgstr = "Total Order = " + transactionCounter.ToString("D") + " Total sales = " + grandTotal.ToString("C")
        MessageBox.Show(msgstr, "Sale summary",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub


    Private Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        If ServiceRadioButton.Checked = True Then
            subtotal = service
        ElseIf TuneupRadioButton.Checked = True Then
            subtotal = tuneUp
        ElseIf TransmissionRadioButton.Checked = True Then
            subtotal = tranService
        ElseIf WheelBalanceRadioButton.Checked = True Then
            subtotal = wheelAlighment
        ElseIf WheelBalanceRadioButton.Checked = True Then
            subtotal = wheelBalance
        ElseIf customerTxtBox.Text = "" Then
            MsgBox("please provide customer name!")
            customerTxtBox.Focus()
        ElseIf CarRegTxtBox.Text = "" Then
            MsgBox("Please provide car number!")
            CarRegTxtBox.Focus()

        Else
            MsgBox("No service is chosen")

        End If
        If DisCheckBox.Checked = True Then
            discountCount = subtotal * discount
            total = discountCount
            TotalTxtBox.Text = total.ToString("C")
        Else
            discountCount = subtotal
            total = discountCount
            TotalTxtBox.Text = total.ToString("C")
        End If
        transactionCounter += 1
        grandTotal += total
        CustomerShowLabel.Text = customerTxtBox.Text
        CarShowLabel.Text = CarRegTxtBox.Text

        If ServiceRadioButton.Checked = True Then
            TedAutoServiceLabel.Text = "Service"
        ElseIf TuneupRadioButton.Checked = True Then
            TedAutoServiceLabel.Text = "Tune Up"
        ElseIf TransmissionRadioButton.Checked = True Then
            TedAutoServiceLabel.Text = "Transmissin Service"
        ElseIf WheelBalanceRadioButton.Checked = True Then
            TedAutoServiceLabel.Text = "Wheel Alignment"
        ElseIf WheelBalanceRadioButton.Checked = True Then
            TedAutoServiceLabel.Text = "Wheel Balancing"
        Else
            TedAutoServiceLabel.Text = ""
        End If
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        ExitButton_Click(sender, e)
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show("This Programme is develop by Khan.  The propose of the programme is calculate total sales and 
         total number of order in auto services.", "Developer Info",
        MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
